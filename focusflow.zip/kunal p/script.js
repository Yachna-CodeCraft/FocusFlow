document.addEventListener('DOMContentLoaded', function () {
  const calendarEl = document.getElementById('calendar');

  const calendar = new FullCalendar.Calendar(calendarEl, {
    initialView: 'dayGridMonth',
    height: 'auto', // 💡 Important: Let it fit content
    contentHeight: 'auto', 
    aspectRatio: 1.5 
    
// helps control width vs height ratio
  });

  
  calendar.render();

  document.getElementById('planForm').addEventListener('submit', function (e) {
    e.preventDefault();
    const title = document.getElementById('title').value;
    const date = document.getElementById('date').value;
    if (title && date) {
      calendar.addEvent({ title, start: date });

      const li = document.createElement('li');
      li.textContent = `${title} (${date})`;
      planList.appendChild(li);

      this.reset();
    }
  });
});

// To-do
function addTodo() {
  const input = document.getElementById("todoInput");
  const task = input.value.trim();
  if (task) {
    const li = document.createElement("li");
    li.textContent = task;
    li.onclick = () => li.remove();
    document.getElementById("todoList").appendChild(li);
    input.value = "";
  }
}

// Pomodoro
let pomodoroTime = 25 * 60;
let timer;
function startPomodoro() {
  if (timer) return;
  timer = setInterval(() => {
    if (pomodoroTime <= 0) {
      clearInterval(timer);
      timer = null;
      alert("Time's up!");
      return;
    }
    pomodoroTime--;
    const min = String(Math.floor(pomodoroTime / 60)).padStart(2, '0');
    const sec = String(pomodoroTime % 60).padStart(2, '0');
    document.getElementById("timer").textContent = `${min}:${sec}`;
  }, 1000);
}
function resetPomodoro() {
  clearInterval(timer);
  timer = null;
  pomodoroTime = 25 * 60;
  document.getElementById("timer").textContent = "25:00";
}
